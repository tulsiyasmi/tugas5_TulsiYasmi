# salmanalfarissy26/pnp 
#Tugas Project 2
#Tugas 3 (pnp)
#Membuat Insert untuk tabel Employees  (folder : HtmlPostData)
#Menampilkan seluruh isi data table Employees (folder : HtmlPage)

#==============================||================================
#Tugas 4 (Framework/git/order)

#==============================||================================
#Tugas 5 (Framework/git/order)
#Request & Response (InquiryPayment fastPay)
